export const environment = {
  production: true,
  homeCategoriesUrl : 'https://littleprodigybooks.in/api/categories',
};
