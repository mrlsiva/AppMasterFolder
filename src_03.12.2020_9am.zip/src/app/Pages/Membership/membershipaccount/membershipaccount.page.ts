import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-membershipaccount',
  templateUrl: './membershipaccount.page.html',
  styleUrls: ['./membershipaccount.page.scss'],
})
export class MembershipaccountPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
